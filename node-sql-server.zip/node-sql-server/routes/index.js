module.exports = {
  authRouter: (router) => {
   require('./dashboard/routes')(router);
  }
};
