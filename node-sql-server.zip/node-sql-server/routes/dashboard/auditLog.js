var connection = require('../config/connectionObj');
module.exports =  {
 getVendor : async (request, response) => {
  try {
    var query ='SELECT * FROM tbl_subject_list';
       [rows, fields]  =  await connection.query(query);
      let list = Object.values(JSON.parse(JSON.stringify(rows)));
      response.send(list)
    } catch (error) {
      response.status(500).send({"kundan":error});
      console.log(error)
    }
}

}
