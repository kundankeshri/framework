var auditLog = require('./auditLog');
var express = require('express');
var router = express.Router();
//var connection = require('../config/connectionObj');
var conn = require('../config/sqlServer');
module.exports = function (router) {
    router.get("/getVendor", auditLog.getVendor);

}