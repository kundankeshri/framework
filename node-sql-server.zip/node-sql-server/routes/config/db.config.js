const config = require( "./app.config" );
console.log('config', config)
module.exports = {
    HOST: config.sql.server,
    USER: config.sql.user,
    PASSWORD: config.sql.password,
    DB: config.sql.database
   };