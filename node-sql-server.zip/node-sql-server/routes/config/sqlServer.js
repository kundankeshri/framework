var dbConfig = {
    driver: 'msnodesqlv8',  
    server: "DESKTOP-C73A3OH\SQLEXPRESS01",
    database: "test",
    user: "Devil",
    password: "P@ssword2512",
    options: {
      trustedConnection: true
  },
  debug: true,
  parseJSON: true
  }; 
  var sql = require('msnodesqlv8');
 // const connectionString ="server=SELT063;Database=AuthDB;username=sa;password=sa;Trusted_Connection=Yes;Driver={SQL Server Native Client 11.0};pool:{max:100,min:1}";
 const connectionString = "server=.;Database=test;Trusted_Connection=Yes;Driver={SQL Server Native Client 11.0}";
  
 sql.open(connectionString, function (err, conn) {
    if(err){
        console.log("Error while connecting to DB :: "+err);
    }else{
        console.log('connected to sql server');
    }
    });

//     sql.connect(dbConfig, function (err) {
//     if (err) { console.log(JSON.stringify(err)+'..............') }
//     else {
//       console.log('Connected')
//     }
//   }
//   );